#ifndef __COLLECTOR_H__
#define __COLLECTOR_H__

// Pathname to UNIX socket 
#define SOCK_PATHNAME "farm.sck"

// Code exec by Collector process
extern void exec_collector();

#endif /* __COLLECTOR_H__ */