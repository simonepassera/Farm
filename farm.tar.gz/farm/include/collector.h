#ifndef __COLLECTOR_H__
#define __COLLECTOR_H__

// Code exec by Collector process
extern void exec_collector();

#endif /* __COLLECTOR_H__ */